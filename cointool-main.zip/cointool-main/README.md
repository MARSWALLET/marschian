# 加密工具
一个让更多人轻松操作链上的工具集合箱，SWAP, 一键发币、创建预售、创建挖矿，行情总览, 批量查余额、批量创建地址、批量发送和归集代币等功能。

#### 原文链接：https://marscoin.site/

![image text](https://github.com/marschainapp/marschain/blob/main/img/web.PNG "web view")

##### 引用地址：

###### SWAP
https://marschain.app/#/swap/myLp  我的流动性

https://marschain.app/#/swap/add   添加流动性

https://marschain.app/#/swap/exchange  兑换

###### 创建预售 私募 (IDO)
https://marschain.app/#/launchpad/standard 标准版

https://marschain.app/#/launchpad/advanced  高级版

https://marschain.app/#/launchpad/advanced  多期版

###### 一键发币
https://marschain.app/#/coin/standard  标准代币

https://.app/#/coin/normal  普通代币

https://marschain.app/#/coin/marketing 营销代币

https://marschain.app/#/coin/dividend  分红代币

https://marschain.app/#/coin/compound  复利代币

https://marschain.app/#/coin/lpdividend  加池分红

https://marschain.app/#/coin/snapshot 快照

###### 创建挖矿
https://marschain.app/#/mining/standard 自由版

https://marschain.app/#/mining/chef   锁仓版

https://marschain.app/#/mining/chefPro 减半版

https://marschain.app/#/mining/chefPlus 高级版

###### 创建锁仓
https://marschain.app/#/lock/index

###### 创建多签钱包
https://marschain.app/#/multi-sig/index

###### 批量发送代币
https://marschain.app/#/batch-send/index

###### 批量归集代币
https://marschain.app/#/batch-collection/index

###### 批量创建钱包
https://marschain.app/#/create-wallet/index

###### 批量查询余额
https://marschain.app/#/check-wallet/index

###### 授权检查
https://marschain.app/#/approve-check/index

###### 靓号地址生成
https://marschain.app/#/vanity-address/index

###### ETH单位转换器
https://marschain.app/#/tool/unit



#### 社交媒体访问：
[💬 Telegram](https://t.me/marschain_app)

[🐦 Twitter](https://twitter.com/marschain_site)
